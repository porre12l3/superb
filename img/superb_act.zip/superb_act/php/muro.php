<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Muro</title>
    <link rel="stylesheet" href="css/login.css">
</head>
<body>
    <div class="slogan">
        <span>"Conectando talento</span>
        <span>con oportunidades."</span>
    </div>
    <div class="login-container">
        <div class="login-box">
            <h2>Publicaciones</h2>
            <div id="anuncios" class="anuncios-container"></div>
        </div>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function() {

        const isLoggedIn = true; 

        if (isLoggedIn) {
           
            fetch('php/obtener_publicacion.php')
                .then(response => response.json())
                .then(data => {
                    const anunciosContainer = document.getElementById('anuncios');
                    data.forEach(publicacion => {
                        const publicacionElement = document.createElement('div');
                        publicacionElement.classList.add('publicacion');
                        publicacionElement.innerHTML = `
                            <h3>${publicacion.titulo}</h3>
                            <p>${publicacion.descripcion}</p>
                            <small>Publicado el ${publicacion.fecha_publicacion}</small>
                        `;
                        anunciosContainer.appendChild(publicacionElement);
                    });
                })
                .catch(error => console.error('Error al obtener las publicaciones:', error));
        } else {
            
            window.location.href = 'login.html';
        }
    });
    </script>
</body>
</html>
