<?php
session_start();
include 'conexion.php'; 

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT id, nombre FROM usuarios WHERE email = ? AND password = ?");
    $stmt->bind_param("ss", $email, $password);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        $_SESSION['nombre'] = $user['nombre']; 
        
        header("Location: muro.html?nombre=" . urlencode($user['nombre']));
        exit();
    } else {
        echo "Correo electrónico o contraseña incorrectos.";
    }

    $stmt->close();
}
$conn->close();
?>
