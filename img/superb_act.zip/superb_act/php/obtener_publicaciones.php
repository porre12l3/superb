<?php

include('conexion.php'); 


$query = "SELECT * FROM publicaciones ORDER BY fecha_publicacion DESC";
$result = mysqli_query($conexion, $query);

$publicaciones = array();
while ($row = mysqli_fetch_assoc($result)) {
    $publicaciones[] = $row;
}


header('Content-Type: application/json');
echo json_encode($publicaciones);
?>
